﻿using System;

namespace Task3
{
    class Program
    {
        static void Main()
        {
            Random rnd = new Random();
            int[] array = new int[10];
            for (int i = 0; i < array.Length; i++) array[i] = rnd.Next(10);
            
            int count = 0;
            for (int i = 0; i < array.Length; i++) 
                Console.Write(array[i] + " ");
            Console.WriteLine();
            Console.Write("Введите число для поиска: ");
            int num = int.Parse(Console.ReadLine());
            
            for (int i = 0; i < array.Length; i++)
                if (array[i] == num) count++;

            Console.WriteLine("Число " + num + " встречается в массиве " + count + " раз");
        }
    }
}
