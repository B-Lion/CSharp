﻿using System;

namespace Task4
{
    class Program
    {
        static void Main()
        {
            int size = 5;
            Random rnd = new Random();
            int[,] matrix = new int[size, size];
            
            for (int i = 0; i < matrix.GetLength(0); i++)
                for (int j = 0; j < matrix.GetLength(1); j++)
                    matrix[i, j] = rnd.Next(10);

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }

            Console.Write("Введите номера столбца №1: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Введите номера столбца №2: ");
            int b = int.Parse(Console.ReadLine());
            if (a < 0 || a > (size - 1) || b < 0 || b > (size - 1))  
            {
                Console.WriteLine("Неправильный номер столбца!");
                return;
            }

            int tmp;

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                tmp = matrix[i, 0];
                matrix[i, a] = matrix[i, b];
                matrix[i, b] = tmp;
            }

            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i, j] + " ");
                }
                Console.WriteLine();
            }



        }
    }
}
