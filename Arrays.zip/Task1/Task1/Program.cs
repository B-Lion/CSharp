﻿using System;
using System.Collections.Generic;

namespace Task1
{
    class Program
    {
        static void Main()
        {
            int[] array = { 1, 0, 2, 6, 8, 0, 0, 5, 5, 0 };
            int zero_count = 0;
            
            for (int i = 0; i < array.Length; i++) 
            {
                if (array[i] == 0) zero_count++;
                else array[i - zero_count] = array[i];
            }
            
            Array.Resize(ref array, array.Length - zero_count);
            int tmp_size = array.Length;
            Array.Resize(ref array, array.Length + zero_count);
            
            for (int i = tmp_size; i < array.Length; i++) array[i] = -1;
            
            for (int i = 0; i < array.Length; i++) Console.Write(array[i] + " ");
        }
    }
}
