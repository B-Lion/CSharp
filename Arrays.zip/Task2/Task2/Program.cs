﻿using System;
using System.Linq;

namespace Task2
{
    class Program
    {
        static void Main()
        {
            Random rnd = new Random();

            int[] array = new int[10];
            
            for (int i = 0; i < array.Length; i++) array[i] = rnd.Next(-10, 10);
            
            int[] copy_array = (int[])array.Clone();
            int count = 0;
            
            for (int i = 0; i < array.Length; i++) 
            {
                if (array[i] > 0 || array[i] == 0) count++;
                else array[i - count] = array[i];
            }
            Array.Resize(ref array, array.Length - count);
            count = 0;
            
            for (int i = 0; i < copy_array.Length; i++)
            {
                if (copy_array[i] < 0) count++;
                else copy_array[i - count] = copy_array[i];
            }
            
            Array.Resize(ref copy_array, copy_array.Length - count);
            Array.Resize(ref array, array.Length + copy_array.Length);
            
            int j = 0;
            for (int i = array.Length - copy_array.Length; i < array.Length; i++) array[i] = copy_array[j++];
            for (int i = 0; i < array.Length; i++) Console.Write(array[i] + " ");


        }
    }
}
