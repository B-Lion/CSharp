﻿using System;

namespace Figures
{
    enum Colors
    {
        RED = ConsoleColor.Red,
        GREEN = ConsoleColor.Green,
        BLUE = ConsoleColor.Blue
    }
    struct Rectangle
    {
        private int a;
        private int b;
        public Rectangle(int a, int b)
        {
            this.a = a; this.b = b;
        }
        public void print(char symbol)
        {
            for (int i = 1; i <= b; i++)
            {
                for (int j = 1; j <= a; j++)
                {
                    Console.Write(symbol);
                }
                Console.WriteLine();
            }
        }
    }
    struct Rhombus
    {
        private int size;
        public Rhombus(int size)
        {
            this.size = size;
        }
        public void print(char symbol)
        {
            int a = size * 2 - 1;
            int b = a / 2;
            for (int i = 0; i < b; i++) 
            {
                for (int j = 0; j < a; j++)
                {
                    if (j <= b + i && j >= b - i)
                        Console.Write(symbol);
                    else 
                        Console.Write(" ");
                }
                Console.WriteLine();
            }
            for (int i = b; i < a; i++)
            {
                for (int j = 0; j < a; j++)
                {
                    if (j <= a + b - i - 1 && j >= i - b)
                        Console.Write(symbol);
                    else
                        Console.Write(" ");
                }
                Console.WriteLine();
            }

        }
    }
    struct Triangle
    {
        private int size;
        public Triangle(int size)
        {
            this.size = size;
        }
        public void print(char symbol)
        {
            for (int i = 1; i <= size; i++)
            {
                for (int j = size; j > i; j--) Console.Write(" ");
                for (int j = 1; j < (2 * i); j++) Console.Write(symbol);
                Console.WriteLine();
            }

        }
    }
    struct Trapezoid
    {
        private int basis;
        private int height;
        public Trapezoid(int basis, int height)
        {
            this.basis = basis;
            this.height = height;
        }
        public void print(char symbol)
        {
            for (int i = 1; i <= height; i++)
            {
                for (int j = 1; j <= basis; j++)
                {
                    Console.Write(symbol);
                }
                basis++;
                Console.WriteLine();
            }

        }
    }
    class Program
    {
        static void Main()
        {
            char symbol;
            string color;
            int size, height;
            Colors tmp_color;
            Colors[] values = Enum.GetValues(typeof(Colors)) as Colors[];

            Console.WriteLine("Добро пожаловать в программу!");
            Console.WriteLine("Выберите фигуру");
            Console.WriteLine("1 - Прямоугольник");
            Console.WriteLine("2 - Ромб");
            Console.WriteLine("3 - Трeугольник");
            Console.WriteLine("4 - Трапеция");
            Console.WriteLine("0 - Выход");
            
            int sw = int.Parse(Console.ReadLine());
            switch(sw)
            {
                case 1:
                    Console.Write("Укажите ширину: ");
                    int a = int.Parse(Console.ReadLine());
                    Console.Write("Укажите высоту: ");
                    int b = int.Parse(Console.ReadLine());
                    Rectangle rectangle = new(a, b);
                    Console.Write("Символ для печати: ");
                    symbol = char.Parse(Console.ReadLine());
                    
                    Console.Write($"Цвет символов [{string.Join(", ", values)}]: ");
                    color = Console.ReadLine();
                    tmp_color = (Colors)Enum.Parse(typeof(Colors), color);
                    Console.ForegroundColor = (ConsoleColor)tmp_color;

                    Console.WriteLine();
                    rectangle.print(symbol);
                    break;
                case 2:
                    Console.Write("Укажите размер ромба (длину стороны): ");
                    size = int.Parse(Console.ReadLine());
                    Rhombus rhombus = new(size);
                    Console.Write("Символ для печати: ");
                    symbol = char.Parse(Console.ReadLine());

                    Console.Write($"Цвет символов [{string.Join(", ", values)}]: ");
                    color = Console.ReadLine();
                    tmp_color = (Colors)Enum.Parse(typeof(Colors), color);
                    Console.ForegroundColor = (ConsoleColor)tmp_color;

                    Console.WriteLine();
                    rhombus.print(symbol);
                    break;
                case 3:
                    Console.Write("Укажите длину стороны: ");
                    size = int.Parse(Console.ReadLine());
                    Triangle triangle = new(size);
                    Console.Write("Символ для печати: ");
                    symbol = char.Parse(Console.ReadLine());

                    Console.Write($"Цвет символов [{string.Join(", ", values)}]: ");
                    color = Console.ReadLine();
                    tmp_color = (Colors)Enum.Parse(typeof(Colors), color);
                    Console.ForegroundColor = (ConsoleColor)tmp_color;

                    Console.WriteLine();
                    triangle.print(symbol);
                    break;
                case 4:
                    Console.Write("Укажите длину верхней основы: ");
                    size = int.Parse(Console.ReadLine());
                    Console.Write("Укажите высоту: ");
                    height = int.Parse(Console.ReadLine());
                    Trapezoid trapezoid = new(size, height);
                    Console.Write("Символ для печати: ");
                    symbol = char.Parse(Console.ReadLine());

                    Console.Write($"Цвет символов [{string.Join(", ", values)}]: ");
                    color = Console.ReadLine();
                    tmp_color = (Colors)Enum.Parse(typeof(Colors), color);
                    Console.ForegroundColor = (ConsoleColor)tmp_color;

                    Console.WriteLine();
                    trapezoid.print(symbol);
                    break;
                case 0:
                    return;
                default:
                    Console.WriteLine("Вы ввели неверную команду!");
                    break;
            }
            Console.ResetColor();
        }
    }
}
